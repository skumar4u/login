<?php
session_start();

include "config.php";

if(isset($_SESSION['username'])){
    header('Location: http://localhost/login/logout.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Login Form</title>
</head>
<body>

    <?php
       
    if(isset($_POST['submit'])){

        if(!empty($_POST['user']) && ($_POST['pass'] === $_POST['rpass'])){

            $user = mysqli_real_escape_string($conn, $_POST['user']);
            $pass = sha1($_POST['pass']);
            $rpass = sha1($_POST['rpass']);
    
        $sql = "INSERT INTO register(user, pass, repass) VALUES('{$user}', '{$pass}', '{$rpass}')"; 
        $result = mysqli_query($conn, $sql);   
        header('Location: http://localhost/login/index.php');
    } else {
        $msg = "Password is not Same";
    } 
}
    ?>
  <div class="container">
        <form class="login-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <h2>Sign up</h2>
            <div class="input-group">
                <label for="username">Name</label>
                <input type="text" name="user" id="username" placeholder="Enter your username" required>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" name="pass" id="password" placeholder="Enter your password" required>
            </div>
            <div class="input-group">
                <label for="password">Retype Password</label>
                <input type="password" name="rpass" id="password" placeholder="Enter your password" required>
            </div>
            <button type="submit" name = "submit">Sign up</button>
            <div class="footer">
                <p>Already! have an account? <a href="http://localhost/login/index.php">Login</a></p>
                <br/> <div align="center" style="color:red;"><b> <?php echo $msg; ?> </b></div>
            </div>
        </form>
    </div>
</body>
</html>
