<?php
session_start();
include "config.php";
if(isset($_SESSION['username'])){
    header('Location: http://localhost/login/logout.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Login Form</title>
</head>
<body>
  <div class="container">
    <form class="login-form" action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
        <h2>Login</h2>
        <b></b>
        <div class="input-group">
          <label for="username">Username *</label>
          <input type="text" name="user" id="username" value="<?php if(isset($_COOKIE['user'])) {echo $_COOKIE['user']; } ?>" placeholder="Enter your username" required/>
        </div>
        <div class="input-group">
          <label for="password">Password *</label>
          <input type="password" name="pass" id="password" value="<?php if(isset($_COOKIE['pass'])) {echo $_COOKIE['pass']; } ?>" placeholder="Enter your password" required/>
        </div class="input-group">
        <div>  
        <input type="checkbox" name="remember" <?php if(isset($_COOKIE['user'])) { ?> checked <?php } ?>> Remember Me
        </div><br/>
        <button type="submit" name = "submit">Login</button>
        <div class="footer">
            <p> Don't have an account? <a href="http://localhost/login/signup.php">Sign up</a></p>
        </div>
    </form>
        <?php 
        if(isset($_POST['submit'])){
            $username = mysqli_real_escape_string($conn, $_POST['user']);
            $password = sha1($_POST['pass']);
            $pass = $_POST['pass'];
           
            $sql = "SELECT * from register where user='{$username}' AND pass='{$password}' ";
           $result = mysqli_query($conn, $sql) or die("query failed");
       
           if(mysqli_num_rows($result) > 0){

                while ($row = mysqli_fetch_assoc($result)){
                   $_SESSION["username"] = $row['user']; 
                   $_SESSION['start'] = time();
                   $_SESSION['expire'] = $_SESSION['start'] + (1*60);        
                    header('Location: http://localhost/login/logout.php');
                }

                if(!empty($_POST['remember'])){
                    setcookie("user",$username,time() +(1*60));
                    setcookie("pass",$pass,time() +(1*60));
                    $_SESSION["username"] = $username;
                } else{
                    if(isset($_COOKIE['user'])){
                        setcookie("user", "");
                    }
                    if(isset($_COOKIE['pass'])){
                        setcookie("pass", "");
                    }    
                }
                header('Location: http://localhost/login/logout.php');
            }
      
            else{
                echo "<br/> <div align='center' style='color:red;'><b> Invalid User or Password </b></div>";
            }
        } 
        ?>
 </div>
</body>
</html>

