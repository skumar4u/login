<?php

$msg = "";
$conn = mysqli_connect("localhost","root","","login") or die("Connection Failed");

?>